import { useState } from 'react'
import './index.css'
import './App.css'
import SideNav from './components/SideNav'

function App() {
    return(
        <SideNav/>
        )
 
}

export default App
