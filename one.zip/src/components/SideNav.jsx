import React from 'react'

export default function SideNav() {
    return (
        <div id='sideNav' className=' w-96 h-screen text-red-500 [color:var(--black1)]'>
            <h1 className='text-red-500'>hello world</h1>
        </div>
    )
}
